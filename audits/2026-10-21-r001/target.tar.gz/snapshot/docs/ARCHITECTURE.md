# Architecture

The v1 protocol has two production contracts:

```mermaid
flowchart LR
  S["Sponsor"] -->|"createRaffle"| F["RaffleFactory"]
  F -->|"deploy once"| I["Locked Raffle implementation"]
  F -->|"ERC-1167 clone + initialize"| R["Raffle clone"]
  R -.->|"delegatecall"| I
  F -->|"escrow exact ERC-721"| R
  B["Buyers / ticket owners"] --> R
  V["Chainlink VRF v2.5 wrapper"] --> R
```

## Fixed-target clones

Each factory constructor deploys one full `Raffle` implementation. Its initializer
is locked in constructor storage. Every canonical raffle is a standard ERC-1167
minimal proxy whose 45-byte runtime permanently names that implementation. There is
no proxy administrator, implementation setter, beacon, CREATE2 salt, or upgrade path.

The implementation holds immutable references to the factory's quote token, Chainlink
wrapper, and factory address. Each clone holds isolated raffle configuration,
ERC-721 ownership and liabilities.

`createRaffle` is one atomic transaction:

1. validate the prize, positive reserve, and sale deadline;
2. create the clone;
3. call its factory-only, one-time initializer;
4. register its address and ID;
5. move the exact prize from sponsor to clone;
6. verify `ownerOf(prizeTokenId) == raffle` and `status == Active`.

Any failure rolls back the clone, registry, event logs, and prize movement.

## Range tickets

One purchase mints one ERC-721 ticket with a simple sequential ID. Its inclusive entry
range is stored separately:

```text
ticket #3 -> { firstEntry: 34, lastEntry: 36 }
```

Ranges are contiguous and non-overlapping because each new range starts at
`totalEntries + 1`. One compact range mapping exists, but no per-entry owner mapping.
The ERC-721 owner of the one ticket containing `winningEntry` owns the outcome.

| Operation                       | Complexity                       |
| ------------------------------- | -------------------------------- |
| buy any positive entry count    | O(1)                             |
| Chainlink callback              | O(1)                             |
| prove, settle, or redeem winner | O(1)                             |
| refund                          | O(tickets supplied), maximum 100 |

## Authority

The factory has no owner, role, pause, upgrade, rescue, or mutable configuration. Its
quote token, Chainlink wrapper, treasury, callback gas, confirmation count, and
implementation are immutable, and raffle creation remains permanently permissionless.

A raffle has no owner, role, pause, rescue, reroll, or configuration setter. Its
sponsor is only a fixed prize/proceeds claimant. No administrator or sponsor can choose
a winner, cancel a sold raffle, or redirect another account's assets.

## Custody and accounting

Each clone escrows exactly one configured ERC-721 and only its own USDC pot. It does
not share balances or mutable state with another raffle. Quote liabilities obey:

```text
accountedQuoteBalance
  = unsettledPot
  + remainingRefundLiability
  + winnerProceeds
  + sponsorProceeds
  + protocolFees
```

Incoming and outgoing transfers use `SafeERC20` and rely on the factory's canonical
USDC trust assumption for standard, fee-free accounting. Known protocol destinations
are rejected for tickets and payouts. Arbitrary future addresses and unrelated
contracts cannot be proven safe onchain and remain user/deployment risks.

The raffle inherits Chainlink Contracts `1.5.0`'s official
`VRFV2PlusWrapperConsumerBase` and uses its `IVRFV2PlusWrapper` and
`VRFV2PlusClient` types for native direct funding. The inherited callback boundary
authenticates the immutable wrapper; the raffle's override performs storage work only.

Winning-ticket settlement also performs storage work only: it proves the range,
records the winning ticket ID, and allocates the economic result and quote liabilities
without reading ownership or burning the ticket. The ticket stays transferable until
its current owner atomically burns it while receiving the NFT or cash through
`redeemWinningTicket`. A failed redemption restores the burn and redemption state.
Sponsor and protocol releases remain independent non-reentrant calls, so winner
inactivity or delivery failure cannot block them after settlement.

Liveness is bounded by two hard, non-overlapping time windows. A sold raffle accepts a
draw request in `[endTime, drawRequestDeadline())`, with refunds available at the
request deadline if no request succeeded. An accepted request resolves only through an
authenticated, ABI-decodable callback included before `callbackDeadline()`; at and
after that deadline the callback is ignored and refunds are available. A request at the
last valid second therefore places the last nominal boundary almost four days after
sale end. Censorship or a reorganization across either cutoff can force refunds.

## Offchain layers

Hardhat artifacts generate the SDK and subgraph ABIs. The subgraph stores one
`Ticket` entity per purchase, never one entity per entry. The web uses indexed data
for discovery but re-reads each raffle directly for transaction decisions; there is
no production Lens contract.
